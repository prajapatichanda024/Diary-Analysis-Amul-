select * from dairy_dataset
----------------------------------------------------------------------------------------------
select * from dairy_dataset where Brand = 'Amul';
--------------------------------------------------------------------------------------------------------
select Product_ID from dairy_dataset
-------------------------------------------------------------------------------------------------------
select distinct revenue from dairy_dataset;
--------------------------------------------------------------------------------------------------------
select Product_id, Customer_Location from dairy_dataset order by Customer_Location;
----------------------------------------------------------------------------------------------
select Product_name from dairy_dataset where Product_name like 'c%';
-------------------------------------------------------------------------------------------------------
select Brand from dairy_dataset where Brand like'%l';
------------------------------------------------------------------------------------------------
select Product_name from dairy_dataset where Product_name like 'Amul';
------------------------------------------------------------------------------------------------
select Product_name from dairy_dataset where Product_name like '[^a]%';
--------------------------------------------------------------------------------------------------------------
select top 50 percent * from dairy_dataset
--------------------------------------------------------------------------------------------------------
select Total_land_Area_acres as total_land  from dairy_dataset
----------------------------------------------------------------------------------------------------------
select count(*) columnsr from dairy_dataset
-------------------------------------------------------------------------------------------------------------
select count(*) as Product_name from dairy_dataset where Brand = 'Amul';
------------------------------------------------------------------------------------------------------------------------------------------------
select sum(Quantity_liters_kg) as total from dairy_dataset;
------------------------------------------------------------------------------------------------------------
select Brand, avg(price_per_unit) as average from dairy_dataset group by Brand;
------------------------------------------------------------------------------------------------------------------------
select sum(revenue) as total from dairy_dataset
-----------------------------------------------------------------------------------------------------------------------------
select Location ,max(Number_of_Cows) as Cows from dairy_dataset Group by location;
----------------------------------------------------------------------------------------------------------------------
select Location ,max(Number_of_Cows) as Cows from dairy_dataset Group by location;
-----------------------------------------------------------------------------------------------------------------------------
select revenue,count(*) as total
from dairy_dataset
group by revenue
having count(*) > 1;
---------------------------------------------------------------------------------------------------------------
select abs(Quantity_liters_kg) as abstract_value from dairy_dataset;
------------------------------------------------------------------------------------------------------------------------
select ceiling(Price_per_unit) as price from dairy_dataset;
---------------------------------------------------------------------------------------------------------
select floor(Total_value) as total from dairy_dataset;
-----------------------------------------------------------------------------------------------
select round(Minimum_Stock,3) as  minimum from dairy_dataset;
----------------------------------------------------------------------------------------------------------
select power(shelf_life_days,2) as  answer from dairy_dataset;
-------------------------------------------------------------------------------------------------------
select sqrt(Price_per_unit) as answer from dairy_dataset;
---------------------------------------------------------------------------------------------------------
select revenue,product_name,
case
when revenue >=10000 then 'high'
when revenue >=5000 then 'mediam'
 else 'low'
end as answer
from dairy_dataset
---------------------------------------------------------------------------------------------
select product_id,minimum_stock,
case
when minimum_stock < 50 then 'low_stock'
when minimum_stock >= 50 then ' sufficient stock'
else 'unkown'
end as answer
from dairy_dataset
------------------------------------------------------------------------------------------------------------------------
select revenue,row_number() over(order by revenue desc) as row_numberss from dairy_dataset
----------------------------------------------------------------------------------------------------------------------------------
select revenue, rank() over(order by revenue) as ans from dairy_dataset
----------------------------------------------------------------------------------------------------------------
select revenue, dense_rank() over(order by revenue) as ans from dairy_dataset
----------------------------------------------------------------------------------------------------------------------------
select product_name,revenue,sum(revenue) over() as sum_revenue from dairy_dataset
---------------------------------------------------------------------------------------------------------------------------------
select product_name,revenue,avg(revenue) over() as sum_revenue from dairy_dataset
-----------------------------------------------------------------------------------------------------------------------
select product_name,revenue,LAG(revenue) over(order by product_name) as previous_revenue from dairy_dataset
-----------------------------------------------------------------------------------------------------------------------------
select product_name,revenue,LEAD(revenue) over(order by revenue) as next_revenue from dairy_dataset
---------------------------------------------------------------------------------------------------------------------------------------
select product_name,revenue from dairy_dataset 
where revenue >(
  select avg(revenue) as avgrage
  from dairy_dataset
  )
----------------------------------------------------------------------------------------------------------------------------------------------------------  
select product_name,revenue from dairy_dataset 
where revenue = (
  select min(revenue) as minimum 
  from dairy_dataset
  )
--------------------------------------------------------------------------------------------------------------------------------------select product_name,revenue from dairy_dataset 
select product_name,revenue from dairy_dataset 
where revenue< (
  select max(revenue) as minimum 
  from dairy_dataset
  )
----------------------------------------------------------------------------------------------------------------------------------
select product_name,revenue from dairy_dataset 
where brand in
(
select brand from  dairy_dataset where brand = 'amul'
)

